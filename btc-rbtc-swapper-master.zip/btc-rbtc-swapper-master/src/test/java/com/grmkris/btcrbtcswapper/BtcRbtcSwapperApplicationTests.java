package com.grmkris.btcrbtcswapper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BtcRbtcSwapperApplicationTests {

    @Test
    void contextLoads() {
    }

}
