
## RSK
- https://blockchain.oodles.io/dev-blog/implementing-ethereum-listener-for-listening-transactions/
- http://docs.web3j.io/4.8.7/advanced/filters_and_events/
- https://www.baeldung.com/web3j
## BTC
- https://bitcoinj.org/working-with-the-wallet#learning-about-changes
- https://bitcoin.stackexchange.com/questions/70063/how-do-i-parse-the-zeromq-messages-in-java

- cookie path `/root/.bitcoin/regtest/.cookie`